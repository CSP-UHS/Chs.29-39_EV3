#!/usr/bin/env python3
from ev3dev2.sound import Sound
sound = Sound()
sound.speak('Hello World!')
sound.beep()
